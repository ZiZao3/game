#include<stdio.h>
#include<stdlib.h>
#include<time.h>

main()
{
	srand(time(0));
	int i,j,k,l,m,n,o;
	//make a table easy for players moving
	printf("\n\n.......Welcome to Golden Goal.........\n\n");
	printf("\nthe map's location is defined as follow:");
	printf("\n(0,0)(0,1)(0,2)(0,3)(0,4)");
	printf("\n(1,0)(1,1)(1,2)(1,3)(1,4)");
	printf("\n(2,0)(2,1)(2,2)(2,3)(2,4)"); 
	printf("\nfor a moving, the things go like king in the chess. Print in the coordinate showed above");
	printf("\n�I���J");
	printf("\n��U ��");
	printf("\n�L���K"); 
	printf("\n...player 1=1, player 2=2, ball=4. Who wana start first to attck?1/2");
	scanf("%d",&o);
	if(o==1){
	int map[3][5]={//start from 1 this time
		{0,0,0,0,0},
		{0,0,5,0,2},
		{0,0,0,0,0},
	};
   for(m=0; m<=2; m++){
   		
   		for(n=0; n<=4; n++){
   			printf("%d\t", map[m][n]);
		   }
		   printf("\n");
	   };
	//print out the list,player 1 is 1, player 2 is 2 and the ball is 4
	i=1,j=2,k=1,l=4;
	int p1,p2;
	p1=map[i][j];
	p2=map[k][l];
	while(map[1][4]!=4&&map[1][4]!=5&&map[1][0]!=4&&map[1][0]!=6){//while gate has not been broken by ball
		if(p1==1||p1==3){//player 1's turn 
			printf("input where p1 want to go, one step move");
			map[i][j]=map[i][j]-1;//take p1 out
			p2=map[k][l];//check with the p2 if they are in same block
			scanf("%d %d",&i,&j);//deternine the new location
			map[i][j]=map[i][j]+1;//put p1 in the block
			p1=map[i][j];//record the new location in p1
			if(p1==7){//tackling determination, only happens when player without ball walk on the block with another one with ball, so inside the normal move 
			    printf("Tackling happpens, move or kick?0/1");
				scanf("%d",&o);
			    if(o==0){//carry the ball after tackling 
					map[i][j]=map[i][j]-5;//ball move with player
					p2=map[k][l];
					printf("where p1 wana go for one step");
				    scanf("%d %d",&i,&j);
				    map[i][j]=map[i][j]+5;
				    p1=map[i][j];
				    if(map[1][4]==4||map[1][4]==5){//check if the p1 is win or not
				    	printf("player1 is the winner");
				    	return 0;
					}
					else{
						for(m=0; m<=2; m++){//print out the court
   		                    for(n=0; n<=4; n++){
   			                    printf("%d\t", map[m][n]);
		                }
		                printf("\n");
	                }
				}   
			}
				else{//kick after tackling 
					map[i][j]=map[i][j]-4;
					p1=map[i][j];//record both player's block
					p2=map[k][l];
					m=(rand()%3)+0;//random i from 0-2
					n=(rand()%(5-j))+j;//random j from j to 4
					map[m][n]=map[m][n]+4;//ball out, man stay
					if(map[1][4]==4||map[1][4]==5){
				    	printf("player1 is the winner");
				    	return 0;
					}
					else{
						for(m=0; m<=2; m++){ 
   		                    for(n=0; n<=4; n++){
   			                    printf("%d\t", map[m][n]);
		                }
		                printf("\n");
	                }
				}   	
			}
		}
			else{//not tackling, just normal move
				for(m=0; m<=2; m++){ 
   		            for(n=0; n<=4; n++){
   			            printf("%d\t", map[m][n]);
		            }
		            printf("\n");
	            };
			}
		}
		else{//p1=5 or 7, they are the same, man carry the ball or grab the ball and go
			printf("p1 kick or move,0/1");
			scanf("%d",&o);
			if(o==1){//take the ball
				map[i][j]=map[i][j]-5;				
				printf("where p1 wana go, one step moving");
				scanf("%d %d",&i,&j);
				map[i][j]=map[i][j]+5;
				p1=map[i][j];
                if(map[1][4]==4||map[1][4]==5){
				    	printf("player1 is the winner");
				    	return 0;
					}
					else{
						for(m=0; m<=2; m++){//print court 
   		                    for(n=0; n<=4; n++){
   			                    printf("%d\t", map[m][n]);
		                }
		                printf("\n");
	                }
				}   
			}
			else{//kick 
				map[i][j]=map[i][j]-4;
				p1=map[i][j];
			    m=(rand()%3)+0;//random i from 0-2
				n=(rand()%(5-j))+j;//random j from j to 4
			    map[m][n]=map[m][n]+4;
			    p2=map[k][l];
			    if(map[1][4]==4||map[1][4]==5){
				    	printf("player1 is the winner");
				    	return 0;
					}
					else{
						for(m=0; m<=2; m++){
   		                    for(n=0; n<=4; n++){
   			                    printf("%d\t", map[m][n]);
		                }
		                printf("\n");
	                }
				}   
			}
		}
		if(p2==2||p2==3){//player 2's turn 
			printf("input where p2 want to go, one step moving");
			map[k][l]=map[k][l]-2;
			p1=map[i][j];
			scanf("%d %d",&k,&l);
			map[k][l]=map[k][l]+2;
			p2=map[k][l];
			if(p2==7){//tackling determination
			    printf("Tackling happpens, move or kick?0/1");
				scanf("%d",&o);
			    if(o==0){//carry ball 
					map[k][l]=map[k][l]-6;
					p1=map[i][j];
					printf("where p2 wana go, one step moving");
				    scanf("%d %d",&k,&l);
				    map[k][l]=map[k][l]+6;
				    p2=map[k][l];
				    for(m=0; m<=2; m++){//print field 
   		                for(n=0; n<=4; n++){
   			                printf("%d\t", map[m][n]);
		                }
		                printf("\n");
	                }
				}
				else{//same as p1's condition 
					map[k][l]=map[k][l]-4;
					p1=map[i][j];
					p2=map[k][l];
					m=(rand()%3)+0;//random m from 0-2
				    n=(rand()%(l+1))+0;//random n from 0 to l
					map[m][n]=map[m][n]+4;
					for(m=0; m<=2; m++){ 
   		                for(n=0; n<=4; n++){
   			                printf("%d\t", map[m][n]);
		                }
		                printf("\n");
	                }
				}
			}
			else{
				for(m=0; m<=2; m++){ 
   		            for(n=0; n<=4; n++){
   			            printf("%d\t", map[m][n]);
		            }
		            printf("\n");
	            };
			}
		}
		else{//p2=6 
			printf("p2 kick or move,0/1");
			scanf("%d",&o);
			if(o==1){//take ball 
				map[k][l]=map[k][l]-6;
				printf("where p2 wana go, one step moving");
				scanf("%d %d",&k,&l);
				map[k][l]=map[k][l]+6;
				p2=map[k][l];
				p1=map[i][j];
                for(m=0; m<=2; m++){
   		            for(n=0; n<=4; n++){
   			            printf("%d\t", map[m][n]);
		            }
		            printf("\n");
	            }
			}
			else{//kick
				map[k][l]=map[k][l]-4;
				p2=map[k][l];
			    m=(rand()%3)+0;//random k from 0-2
				n=(rand()%(l+1))+0;//random l from 0 to l
			    map[m][n]=map[m][n]+4;
			    p1=map[i][j];
			    for(m=0; m<=2; m++){
   		            for(n=0; n<=4; n++){
   			            printf("%d\t", map[m][n]);
		            }
		            printf("\n");
	            }
			}
		}
	}
	printf("Gameover");
	if(map[1][4]==4||map[1][4]==5){
		printf("player 1 is the winner");
	}
	else{
		printf("player 2 is the winner");
	}
   return 0;
}
else{//player 1 defend and player 2 attack
	int map[3][5]={
		{0,0,0,0,0},
		{1,0,6,0,0},
		{0,0,0,0,0},
	};
   for(i=0; i<=2; i++){
   		
   		for(j=0; j<=4; j++){
   			printf("%d\t", map[i][j]);
		   }
		   printf("\n");
	   };
	i=1,j=0,k=1,l=2;
	int p1,p2;
	p1=map[i][j];
	p2=map[k][l];
	while(map[1][4]!=4&&map[1][4]!=5&&map[1][0]!=4&&map[1][0]!=6){
		if(p2==2||p2==3){//player 2's turn first
			printf("input where p2 want to go, one step moving");
			map[k][l]=map[k][l]-2;
			p1=map[i][j];
			scanf("%d %d",&k,&l);//
			map[k][l]=map[k][l]+2;
			p2=map[k][l];
			if(p1==7){ 
			    printf("Tackling happpens, move or kick?0/1");
				scanf("%d",&o);
			    if(o==0){ 
					map[k][l]=map[k][l]-6;
					p1=map[i][j];
					printf("where p2 wana go, one step moving");
				    scanf("%d %d",&k,&l);//
				    map[k][l]=map[k][l]+6;
				    p2=map[k][l];
				    if(map[1][0]==4||map[1][0]==6){//player 2's turn so check with p2 is win or not, there's no need to wait for the end of this round
				    	printf("player 2 is the winner");
				    	return 0;
					}
					else{
						for(m=0; m<=2; m++){ 
   		                    for(n=0; n<=4; n++){
   			                    printf("%d\t", map[m][n]);
		                }
		                printf("\n");
	                }
				}   
			}//
				else{ 
					map[k][l]=map[k][l]-4;
					p1=map[i][j];
					p2=map[k][l];
					m=(rand()%3)+0;//random m from 0-2
					n=(rand()%(l+1))+0;//random n from 0 to j
					map[m][n]=map[m][n]+4;
					if(map[1][0]==4||map[1][0]==6){
				    	printf("player 2 is the winner");
				    	return 0;
					}
					else{
						for(m=0; m<=2; m++){ 
   		                    for(n=0; n<=4; n++){
   			                    printf("%d\t", map[m][n]);
		                }
		                printf("\n");
	                }
				}   	
			}
		}
			else{
				for(m=0; m<=2; m++){ 
   		            for(n=0; n<=4; n++){
   			            printf("%d\t", map[m][n]);
		            }
		            printf("\n");
	            };
			}
		}
		else{ 
			printf("p2 kick or move,0/1");
			scanf("%d",&o);
			if(o==1){ 
				map[k][l]=map[k][l]-6;				
				printf("where p2 wana go, one step moving");
				scanf("%d %d",&k,&l);
				map[k][l]=map[k][l]+6;
				p2=map[k][l];
                if(map[1][0]==4||map[1][0]==6){
				    	printf("player 2 is the winner");
				    	return 0;
					}
					else{
						for(m=0; m<=2; m++){ 
   		                    for(n=0; n<=4; n++){
   			                    printf("%d\t", map[m][n]);
		                }
		                printf("\n");
	                }
				}   
			}
			else{ 
				map[k][l]=map[k][l]-4;
				p2=map[k][l];
			    m=(rand()%3)+0;//random m from 0-2
				n=(rand()%(l+1))+l;//random n from 0 to l
			    map[m][n]=map[m][n]+4;
			    p1=map[i][j];
			    if(map[1][0]==4||map[1][0]==6){
				    	printf("player 2 is the winner");
				    	return 0;
					}
					else{
						for(m=0; m<=2; m++){ 
   		                    for(n=0; n<=4; n++){
   			                    printf("%d\t", map[m][n]);
		                }
		                printf("\n");
	                }
				}   
			}
		}
		if(p1==1||p1==3){//player 1 go next
			printf("input where p1 want to go, one step moving");
			map[i][j]=map[i][j]-1;
			p2=map[k][l];
			scanf("%d %d",&i,&j);
			map[i][j]=map[i][j]+1;
			p1=map[i][j];
			if(p1==7){ 
			    printf("Tackling happpens, move or kick?0/1");
				scanf("%d",&o);
			    if(o==0){ 
					map[i][j]=map[i][j]-5;
					p2=map[k][l];
					printf("where p1 wana go");
				    scanf("%d %d",&i,&j);
				    map[i][j]=map[i][j]+5;
				    p1=map[i][j];
				    for(m=0; m<=2; m++){ 
   		                for(n=0; n<=4; n++){
   			                printf("%d\t", map[m][n]);
		                }
		                printf("\n");
	                }
				}
				else{
					map[i][j]=map[i][j]-4;
					p1=map[i][j];
					p2=map[k][l];
					m=(rand()%3)+0;//random m from 0-2
				    n=(rand()%(5-j))+j;//random n from j to 4
					map[m][n]=map[m][n]+4;
					for(m=0; m<=2; m++){ 
   		                for(n=0; n<=4; n++){
   			                printf("%d\t", map[m][n]);
		                }
		                printf("\n");
	                }
				}
			}//
			else{
				for(m=0; m<=2; m++){ 
   		            for(n=0; n<=4; n++){
   			            printf("%d\t", map[m][n]);
		            }
		            printf("\n");
	            };
			}
		}
		else{
			printf("p1 kick or move,0/1");
			scanf("%d",&o);
			if(o==1){
				map[i][j]=map[i][j]-5;
				printf("where p1 wana go");
				scanf("%d %d",&i,&j);
				map[i][j]=map[i][j]+5;
				p2=map[k][l];
				p1=map[i][j];
                for(m=0; m<=2; m++){ 
   		            for(n=0; n<=4; n++){
   			            printf("%d\t", map[m][n]);
		            }
		            printf("\n");
	            }
			}
			else{ 
				map[i][j]=map[i][j]-4;
				p1=map[i][j];
			    m=(rand()%3)+0;//random m from 0-2
				n=(rand()%(5-j))+j;//random n from j to 4
			    map[m][n]=map[m][n]+4;
			    p2=map[m][n];
			    for(m=0; m<=2; m++){ 
   		            for(n=0; n<=4; n++){
   			            printf("%d\t", map[m][n]);
		            }
		            printf("\n");
	            }
			}
		}
	}
	printf("Gameover");
	if(map[1][4]==4||map[1][4]==5){
		printf("player 1 is the winner");
	}
	else{
		printf("player 2 is the winner");
	}
   return 0;
}
}

			
			
        	
		

    	
	
        
	
    
	
	


